package com.example.jeslin.qrscanner;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

//implementing onclicklistener
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //View Objects
    private Button buttonScan, Submit;
    private TextView textViewName, textViewId, date, Time, Department;

    //qr code scanner object
    private IntentIntegrator qrScan;

    Spinner spinner;


    String[] s = {"1", "2", "3", "4", "5", "6", "7", "8"};

    ArrayAdapter arrayAdapter;

    ProgressDialog pd;
    HttpClient httpClient;
    HttpPost httpPost;
    HttpResponse httpResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //View objects
        buttonScan = (Button) findViewById(R.id.buttonScan);
   /*     Submit = (Button) findViewById(R.id.Submit);
        textViewName = (TextView) findViewById(R.id.textViewName);
        textViewId = (TextView) findViewById(R.id.ID);
        date = (TextView) findViewById(R.id.Date);
        spinner = (Spinner) findViewById(R.id.hour);
        Time = (TextView) findViewById(R.id.Time);
        Department = (TextView) findViewById(R.id.Department);
        Submit.setVisibility(View.INVISIBLE);
        arrayAdapter = new ArrayAdapter(getApplicationContext(), R.layout.color, s);

        spinner.setAdapter(arrayAdapter);
        spinner.setPrompt("Title");*/
        //intializing scan object
        qrScan = new IntentIntegrator(this);

/*        Date c = Calendar.getInstance().getTime();
        System.out.println("Current time => " + c);

        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(c);

        SimpleDateFormat df3 = new SimpleDateFormat("HH:mm:ss a");
        String formattedDate3 = df3.format(c.getTime());
        date.setText(formattedDate);
        Time.setText(formattedDate3);*/

        //attaching onclick listener
        buttonScan.setOnClickListener(this);

/*
        Submit.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                pd = ProgressDialog.show(MainActivity.this, "", "Logging in...",
                        false, true);
                new Thread() {
                    public void run() {
                        try {

                            httpClient = new DefaultHttpClient();
                            httpPost = new HttpPost(Ipaddress.URL);
                            List<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();

                            nameValuePair.add(new BasicNameValuePair(
                                    "flag", "12"));

                            nameValuePair.add(new BasicNameValuePair(
                                    "textViewName", textViewName.getText().toString()));
                            nameValuePair.add(new BasicNameValuePair(
                                    "textViewId", textViewId.getText()
                                    .toString()));

                            nameValuePair.add(new BasicNameValuePair(
                                    "department", Department.getText()
                                    .toString()));

                            nameValuePair.add(new BasicNameValuePair(
                                    "hour", spinner.getSelectedItem().toString()));
                            nameValuePair.add(new BasicNameValuePair(
                                    "time", Time.getText()
                                    .toString()));

                            nameValuePair.add(new BasicNameValuePair(
                                    "date", date.getText()
                                    .toString()));
                            nameValuePair.add(new BasicNameValuePair(
                                    "status", "Present"));

                            httpPost.setEntity(new UrlEncodedFormEntity(
                                    nameValuePair));
                            httpResponse = httpClient.execute(httpPost);
                            InputStream inputStream = httpResponse
                                    .getEntity().getContent();

                            InputStreamReader inputStreamReader = new InputStreamReader(
                                    inputStream);

                            BufferedReader bufferedReader = new BufferedReader(
                                    inputStreamReader);

                            StringBuilder stringBuilder = new StringBuilder();

                            String bufferedStrChunk = null;

                            while ((bufferedStrChunk = bufferedReader
                                    .readLine()) != null) {
                                stringBuilder.append(bufferedStrChunk);
                            }
                            System.out.println("Login :"
                                    + stringBuilder.toString());
                            if (stringBuilder.toString().trim()
                                    .equals("yes")) {

                                Toast.makeText(getApplicationContext(), "Registered Sucessfully", Toast.LENGTH_SHORT).show();
                                clear();
//                                        handler.sendEmptyMessage(2);
                            } else {

//                                        handler.sendEmptyMessage(1);
                                Toast.makeText(getApplicationContext(), "11Registered Sucessfully", Toast.LENGTH_SHORT).show();


                            }

                        } catch (Exception e) {
                        }
                    }
                }.start();
                pd.dismiss();
                finish();

            }
//                else {
//
//                    Toast.makeText(getApplicationContext(), "Fields cant be empty", Toast.LENGTH_SHORT).show();
//
//
//                }


        });*/


    }

   /* private void clear() {
        textViewName.setText("");
        textViewId.setText("");
        date.setText("");
        Time.setText("");
        Department.setText("");
    }*/

    //Getting the scan results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
             /*   try {
                    //converting the data to json
                    JSONObject obj = new JSONObject(result.getContents());
                    //setting values to textviews
//                    textViewName.setText(result.getContents().toString());
//                    textViewId.setText(obj.getString("text"));
                } catch (JSONException e) {*/
                   // e.printStackTrace();
                    //if control comes here
                    //that means the encoded format not matches
                    //in this case you can display whatever data is available on the qrcode
                    //to a toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();

//                    textViewName.setText(result.getContents().toString());
//                    textViewAddress.setText(obj.getString("text"));


                 /*   Submit.setVisibility(View.VISIBLE);
                    String str = new String(result.getContents());*/
            /*        System.out.println("split(String regex):");
                    String array1[] = str.split("/");
                    for (String temp : array1) {
                        System.out.println(temp);
                        String part0 = array1[0];
                        String part1 = array1[1];
                        String part2 = array1[2];
                       *//* textViewName.setText(part0);

                        textViewId.setText(part1);
                        Department.setText(part2);*//*


                    }*/
                    Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this,UnitPerDay.class);
                    startActivity(i);
               // }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onClick(View view) {
        //initiating the qr code scan
        qrScan.initiateScan();
    }
}