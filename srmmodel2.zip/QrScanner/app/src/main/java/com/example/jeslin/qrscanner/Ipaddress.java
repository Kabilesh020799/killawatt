package com.example.jeslin.qrscanner;

/**
 * Created by JESLIN on 8/1/2018.
 */

class Ipaddress {

    public static final String URL = "http://192.168.1.18:8080/HttpGetServlet/HelloWorldServlet";

}
