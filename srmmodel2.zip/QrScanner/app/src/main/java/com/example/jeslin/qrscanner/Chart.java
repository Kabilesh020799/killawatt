package com.example.jeslin.qrscanner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import android.widget.Toast;

import java.util.ArrayList;

public class Chart extends AppCompatActivity implements OnChartValueSelectedListener {
    Button b,check;
    PieChart pieChart;
    TextView avg,rmng;

    SQLiteDatabase sq;
    Cursor c;

    ArrayList<String> ulist=new ArrayList<String>();

    Intent in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);


        avg=(TextView)findViewById(R.id.average_chart);
        rmng=(TextView)findViewById(R.id.remaining_chart);
        pieChart = (PieChart) findViewById(R.id.piechart2);
        b=(Button)findViewById(R.id.result2);
        check=(Button)findViewById(R.id.check_status);
        pieChart.setUsePercentValues(true);

        in=getIntent();

        sq=openOrCreateDatabase("userdata",MODE_PRIVATE,null);
        sq.execSQL("create table if not exists unit(date varchar(20),unitvalue varchar(30))");

        sq.close();

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int tcount=0,ucount=0;
                float avg1,remg1;

                sq=openOrCreateDatabase("userdata",MODE_PRIVATE,null);

                c=sq.rawQuery("select unitvalue from unit;",null);

                if(c.moveToFirst())
                {
                    do {
                        ulist.add(c.getString(0));
                        tcount=tcount+1;
                    }
                    while(c.moveToNext());
                    sq.close();

                    for (int i=0;i<ulist.size();i++)
                    {
                        ucount+=Integer.parseInt(ulist.get(i));
                    }

                    avg1=ucount/tcount;
                    remg1=(200-ucount)/(70-tcount);

                    avg.setText("average : "+String.valueOf(avg1));
                    rmng.setText("Remaining : "+String.valueOf(remg1));
                    sq=openOrCreateDatabase("userdata",MODE_PRIVATE,null);
                    sq.execSQL("insert into unit values('"+in.getStringExtra("date")+"','"+in.getStringExtra("unit")+"')");
                    sq.close();



                    SharedPreferences shared=getSharedPreferences("shared2",MODE_PRIVATE);
                    String s1=shared.getString("1","");
                    float f=Float.parseFloat(s1);
                    Toast.makeText(getApplicationContext(),String.valueOf(f),Toast.LENGTH_LONG).show();
                    String s2=shared.getString("2","");
                    //  float f1=Float.parseFloat(s2);
                    Toast.makeText(getApplicationContext(),s2,Toast.LENGTH_SHORT).show();
                    float f2=f/(200/70);
                    Toast.makeText(getApplicationContext(),String.valueOf(f2),Toast.LENGTH_LONG).show();

                    ArrayList<Entry> yvalues = new ArrayList<Entry>();
                    yvalues.add(new Entry(avg1, 0));
                    yvalues.add(new Entry(remg1, 1));



                    PieDataSet dataSet = new PieDataSet(yvalues, " Results");

                    ArrayList<String> xVals = new ArrayList<String>();

                    xVals.add("Unit");
                    xVals.add("Threshold");


                    PieData data = new PieData(xVals, dataSet);
                    data.setValueFormatter(new PercentFormatter());
                    pieChart.setData(data);
                    pieChart.setDescription("This is Pie Chart");

                    pieChart.setDrawHoleEnabled(true);
                    pieChart.setTransparentCircleRadius(25f);
                    pieChart.setHoleRadius(25f);

                    dataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);
                    data.setValueTextSize(10f);
                    data.setValueTextColor(Color.DKGRAY);
                    pieChart.setOnChartValueSelectedListener(Chart.this);

                    pieChart.animateXY(1400, 1400);

                }
                else
                {
                    sq.close();
                    Toast.makeText(getApplicationContext(),"no data found",Toast.LENGTH_SHORT).show();
                    avg.setText("average : 0");
                    rmng.setText("remaining : 0");
                }


            }
        });

        getvalue();
    }

    @Override
    protected void onResume() {
        super.onResume();

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getvalue();
            }
        });
    }

    @Override
    public void onValueSelected(Entry e, int dataSetIndex, Highlight h) {
        if (e == null)
            return;
        Log.i("VAL SELECTED",
                "Value: " + e.getVal() + ", xIndex: " + e.getXIndex()
                        + ", DataSet index: " + dataSetIndex);

    }

    @Override

    public void onNothingSelected() {
        Log.i("PieChart", "nothing selected");

    }

    public void getvalue()
    {
        int tcount=0,ucount=0;
        float avg1,remg1;

        sq=openOrCreateDatabase("userdata",MODE_PRIVATE,null);

        c=sq.rawQuery("select unitvalue from unit;",null);

        if(c.moveToFirst())
        {
            do {
                ulist.add(c.getString(0));
                tcount=tcount+1;
            }
            while(c.moveToNext());
            sq.close();

            for (int i=0;i<ulist.size();i++)
            {
                ucount+=Integer.parseInt(ulist.get(i));
            }

            avg1=ucount/tcount;
            remg1=(200-ucount)/(70-tcount);

            avg.setText("average : "+String.valueOf(avg1));
            rmng.setText("Remaining : "+String.valueOf(remg1));

        }
        else
        {
            sq.close();
            Toast.makeText(getApplicationContext(),"no data found",Toast.LENGTH_SHORT).show();
            avg.setText("average : 0");
            rmng.setText("remaining : 0");
        }



    }
}
