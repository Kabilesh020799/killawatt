package com.nicktrick.db;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 *
 */

public class CreateDb
{
    public static DatabaseReference root,uniqueid,username,usermail,phoneno,register;
    public CreateDb()
    {
        root= FirebaseDatabase.getInstance().getReference();
     /* uniqueid=root.child("uniqueid");
        username=root.child("username");
        usermail=root.child("usermail");
        phoneno=root.child("phoneno");*/
        register=root.child("register");

    }
}
