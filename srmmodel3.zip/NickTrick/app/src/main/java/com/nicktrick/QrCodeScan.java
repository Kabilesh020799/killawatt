package com.nicktrick;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nicktrick.firebase.Person;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QrCodeScan extends AppCompatActivity {
    public static final int MODE_PRIVATE = 0;
    public static final int RESULT_OK = -1;
    public static final int RESULT_CANCELED = 0;
    private ImageView Clickbtn;
    private Button Sendbtn;
    String getcode, contents, format,mbl,uid;
    private DatabaseReference databaseReference;
    List<String> val =new ArrayList<>();
    Map<String,String> valmap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qrscan);
        Clickbtn = findViewById(R.id.btnqrs);
        databaseReference = FirebaseDatabase.getInstance().getReference("register");






        Clickbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(
                        "com.google.zxing.client.android.SCAN");
                intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
                startActivityForResult(intent, 0);
            }
        });

    }
    private void addChildEventListener() {
        databaseReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Person person = dataSnapshot.getValue(Person.class);
                if (person != null) {
                    person.setKey(dataSnapshot.getKey());
                    if(val.contains(person.getUniqid())){

                    }else{
                        val.add( person.getUniqid());
                        valmap.put(person.getUniqid(),person.getMobile());
                        uid = person.getUniqid();
                        mbl = person.getMobile();
                        Log.e("res--mob--num---uid", mbl + "-----" + uid);

                    }

                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

            public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        try {
            String dates = "";
            String time = "";
            if (requestCode == 0) {
                if (resultCode == RESULT_OK) {
                    contents = intent.getStringExtra("SCAN_RESULT");
                    format = intent.getStringExtra("SCAN_RESULT_FORMAT");
                    // Handle successful scan

                    // Toast toast = Toast.makeText(this, "Content:" + contents
                    // + " Format:" + format , Toast.LENGTH_LONG);
                    // toast.setGravity(Gravity.TOP, 25, 400);
                    // toast.show();
                  //----addchildlistener
                    addChildEventListener();

                    String pnum = contents;
                    Log.e("code",pnum);
                   //String pnum = "0002";
                    for(Map.Entry<String,String> entry : valmap.entrySet()) {
                        String key = entry.getKey();
                        Log.e("inside qr",key);

                        if(key.trim().equals(pnum.trim())) {

                            String phnval = entry.getValue();
                            Intent it = new Intent(QrCodeScan.this, VerifyOtp.class);
                            it.putExtra("phn",phnval);
                            it.putExtra("uid",pnum);
                            startActivity(it);
                        }else{
                           // Toast.makeText(getApplicationContext(),"Wrong Qr code",Toast.LENGTH_SHORT).show();
                        }


                        // do what you have to do here
                        // In your case, another loop.
                    }


                    // Toast.makeText(getActivity(), "status"+url,
                    // Toast.LENGTH_LONG).show();

                } else if (resultCode == RESULT_CANCELED) {
                    // Handle cancel
                    Toast.makeText(getApplicationContext(),
                            "Sorry Scan cancelled", Toast.LENGTH_LONG).show();

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



}
