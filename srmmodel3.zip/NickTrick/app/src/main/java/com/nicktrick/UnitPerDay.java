package com.nicktrick;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class UnitPerDay extends AppCompatActivity {
    TextView t,t1;
    EditText e;
    Handler mHandler;
    private int nCounter = 0;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_per_day);
        t=(TextView)findViewById(R.id.u1);
        t1=(TextView)findViewById(R.id.u3);
        e=(EditText)findViewById(R.id.u2);
        b=(Button)findViewById(R.id.u4);
        String count=Integer.toString(nCounter);
        e.setText(count);
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("yyyy / MM / dd ");
        String strDate = mdformat.format(calendar.getTime());
        t.setText(strDate);
        String text=t.getText().toString();
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t1.setText(" Threshold:200 ");
            }
        });

//    Handler h = new Handler();
//    int delay = 3000; //milliseconds

//    h.postDelayed(new Runnable() {
//        public void run() {
//            String count = Integer.toString(nCounter);
//            e.setText(count);
//            h.postDelayed(this, delay);
//        }
//    }, delay);
//
//    nCounter += 100;

    }
    private Timer timer;
    private TimerTask timerTask;


    public void onResume(){
        super.onResume();

        start(3000,3000,5);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(UnitPerDay.this,e.getText().toString(),Toast.LENGTH_LONG).show();
                SharedPreferences shared=getSharedPreferences("shared2",MODE_PRIVATE);
                SharedPreferences.Editor ed=shared.edit();

                ed.putString("1",e.getText().toString());
                ed.putString("2","200");
                ed.commit();
                Intent in=new Intent(UnitPerDay.this,Chart.class);
                in.putExtra("date",t.getText().toString());
                in.putExtra("unit",e.getText().toString());
                startActivity(in);
            }
        });

    }

    public void start(long delay, long period, final int contnum)
    {
        try {
            timer = new Timer();
            timerTask = new TimerTask() {
                @Override
                public void run() {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String count=Integer.toString(nCounter);
                            e.setText(count);
                            nCounter +=contnum;
                        }
                    });
                }
            };
            timer.schedule(timerTask, delay, period);
        } catch (IllegalStateException e){
            android.util.Log.i("Damn", "resume error");
        }
    }

}
