package com.nicktrick;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.QuickContactBadge;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nicktrick.firebase.Person;
import com.nicktrick.usage.Usage;
import com.nicktrick.usage.UsageAdapter;
import com.nicktrick.usage.Usagebean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VerifyPass extends AppCompatActivity {
    ListView listView;
    private DatabaseReference databaseReference;
    private UsageAdapter usageAdapter;
    List<String> val = new ArrayList<>();
    Map<String, String> valmap = new HashMap<>();
    private List<Usagebean> listPerson = new ArrayList<>();
    String uid="",pws="";
    EditText getvpass;
    Button verify;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verifypassword);
        listView = findViewById(R.id.usagelistView);
        verify = findViewById(R.id.btn_verifypass);
        getvpass = findViewById(R.id.get_vfpass);
        databaseReference = FirebaseDatabase.getInstance().getReference("usage");
        usageAdapter = new UsageAdapter(this, listPerson);


        SharedPreferences btnpref = getApplicationContext().getSharedPreferences("Btnpref", Context.MODE_PRIVATE);

        uid=getIntent().getStringExtra("uid");
        Log.e("print uid",uid);
        addChildEventListener();
        verify.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String val = btnpref.getString(uid,"");
        String[] valarry = val.split("@");
        pws=valarry[1].toString().trim();
        String gtpass=getvpass.getText().toString();
        if (gtpass.equals(pws)){
            Toast.makeText(VerifyPass.this, "Success !", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(VerifyPass.this, "Incorrect password !", Toast.LENGTH_SHORT).show();
        }
    }
});

    }


    private void addChildEventListener() {
        databaseReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Usage person = dataSnapshot.getValue(Usage.class);
                if (person != null) {
                    person.setKey(dataSnapshot.getKey());
                    //dataSnapshot.getKey()
                                  /*  if (val.contains(person.getUniqid())) {

                    } else {*/
                        val.add(person.getUniqid());
                        valmap.put(person.getUniqid(),person.getUniqid()+"@"+person.getUsage()+"@"+person.getDater());
                       // }

                    Usagebean ub = new Usagebean();
                    for(Map.Entry<String,String> entry : valmap.entrySet()) {
                        String key = entry.getKey();

                        if(key.equals(uid)) {

                            String mpval=entry.getValue();
                            Log.e("map",mpval);
                            String[] val = mpval.split("@");
                            ub.setUniqid("Uid : "+val[0]);
                            ub.setUsage("Usage: "+val[1]);
                            ub.setDater("Date : "+val[2]);

                            listPerson.add(ub);

                          /*  ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                                    android.R.layout.simple_list_item_1, android.R.id.text1, val);
                            listView.setAdapter(adapter);*/
                        }
                    }

                    listView.setAdapter(usageAdapter);




                }

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
