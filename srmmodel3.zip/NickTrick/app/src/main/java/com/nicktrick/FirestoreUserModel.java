package com.nicktrick;

public class FirestoreUserModel {
    String uniquecode="",phonenum="",username="", password ="";

   /* public FirestoreUserModel(String uniquecode, String phonenum, String username, String password) {
        this.uniquecode = uniquecode;
        this.phonenum = phonenum;
        this.username = username;
        this.password = password;
    }*/

    public String getUniquecode() {
        return uniquecode;
    }

    public void setUniquecode(String uniquecode) {
        this.uniquecode = uniquecode;
    }

    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
